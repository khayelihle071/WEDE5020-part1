#part 2 improvement
1. From the feedback i got from  my lecturer for part 2 was to style my work more 
2. i am going to add the verification forms and fix the minior spelling errors and fix the pictures
3. i am going to add SEO in all my web pages using meta tags

referenceing 
1.https://www.w3schools.com/howto/howto_js_lightbox.asp
2.https://www.w3schools.com/js/js_validation.asp
3.https://www.w3schools.com/tags/tag_meta.asp