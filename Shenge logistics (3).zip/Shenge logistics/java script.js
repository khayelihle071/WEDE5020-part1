const contactForm = document.getElementById("contactForm");
const submitBtn = document.getElementById("submitBtn");
const formStatus = document.getElementById("formStatus");
const admimEmail = "khayelihle071@gmail.com"

contactForm.addEventListener("submit",async function (event){
    Event.preventDefault();
    if(!contactForm.checkValidity()){
        contactForm.reportValidity();
        return;
    }
    const name = document.getElementById("name").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const message = document.getElementById("message").value.trim();

   const phonePattern = /^\+?[0-9()-]{9,20}$/;

   if (!phonePattern.test(phone)){
    alert("Enter a valid phone number.")
    return;
   }
   
   if (message.length <10){
    alert("message must contain at least 10 characters.");
    return;
   }

   submitBtn.disabled = true;
   submitBtn.textContent = "Sending..";
   formStatus.textContent = "submitting your message..";

   try{
    const Response = await fetch("https://formsubmit.co/ajax" + encodelURIComponent(adminEmail)
    ,{
        method:"POST",
         headers: {
            "Content-Type":"application/json",
            "Accept": "application/json"
        },
        body: JSON.stringify({
            name: name,
            email: document.getElementById("email").value.trim(),
            phone: phone,
            subject: document.getElementById("subject").value,
            message: message,
            _subject: "New website contact form Submission",
            _template:"table"
        })
    });

   const result = await response.json();

   if(
    Response.ok &&
    (
        result.success === true ||
        result.success === "true"
    )
   ){
    alert("Your information has been sent successfully!");

    formStatus.textContent = 
    "Thank you,has message has been submitted";

    contactForm,reset();
   }else{
    throw new Error(
        result.message || "The email service did not confirm submission"
    );
   }
}catch (error){
    console.error("Form submission error:", error);
    formStatus.textContent.consent ="sorry your messagecould not be confirmed.Please try again.";

    alert(
        "Message not confrimed.PLease check your connection " + " or try again later."
    );
}finally{
    submitBtn.disabled = false;
    submitBtn.textContent = "Send Message";
}
});
